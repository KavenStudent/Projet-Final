<script src="../../client/js/jquery-3.6.0.min.js"></script>
<link rel="stylesheet" href="../../client/utilitaires/bootstrap-5.1.0-dist/css/bootstrap.min.css">
</script>
<script src="../../client/utilitaires/bootstrap-5.1.0-dist/js/bootstrap.min.js"></script>
<script src="../../client/public/js/script.js"></script>
<link rel="stylesheet" href="../../client/public/css/style.css">
<?php

    define ("FICHIER1", "../donnees/programmeurs.txt");

    $fic=fopen(FICHIER1, "r");

    $ligne=fgets($fic);

    $jourPost = $_POST['selectJour'];
?>
<div id="tableQ2" class="container">
    <h3>GESTION DE CONSOMMATION DE CAFÉ POUR LA JOURNÉE DE <?=strtoupper($jourPost)?></h3>
    <button id="closeButton" type="button" class="btn-close" aria-label="Close" onclick="closeTableQ2()"></button>
    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col">Programmeurs qui ont consommé du café</th>
            </tr>
        </thead>
        <tbody>

            <?php

    while(!feof($fic)){

        $tab=explode(";",$ligne);

        $programmeur = $tab[0];
        $jour = $tab[1];
        $tasseCafe = $tab[2];
        if ($jour === $jourPost) {
?>
            <tr>
                <td><?=$programmeur?></th>
                <?php
        }
        $ligne=fgets($fic);
    }

    fclose($fic);
?>
        </tbody>
    </table>
</div>
<div class="container">
    <br>
    <br>
    <a href="../programmeurs.html"><button type="button" class="btn btn-secondary">RETOUR</button></a>
</div>