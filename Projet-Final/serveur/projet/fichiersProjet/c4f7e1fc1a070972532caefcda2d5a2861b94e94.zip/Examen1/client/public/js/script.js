function sendFormQ1() {
    document.getElementById("formQ1").submit();
}

function showFormQ2() {
    document.getElementById("formQ2").style.display = 'block';
    document.getElementById("formQ3").style.display = 'none';
}

function showFormQ3() {
    document.getElementById("formQ3").style.display = 'block';
    document.getElementById("formQ2").style.display = 'none';
}

function closeTableQ1() {
    document.getElementById("tableQ1").style.display = "none";
}

function closeTableQ2() {
    document.getElementById("tableQ2").style.display = "none";
}