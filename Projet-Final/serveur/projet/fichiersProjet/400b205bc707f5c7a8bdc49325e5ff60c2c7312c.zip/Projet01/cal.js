let input=""; // les donnes qu'on rentre
let total;

// Fonction qui affiche le bouton qu'on pese dans le output
function showValue(btn){
    input += btn.name;
    document.getElementById('output').innerHTML = input;
}

//Fontion qui fait le calcule
function doMath(){
    total=eval(input)
    document.getElementById('output').innerHTML = total ;
    input = total;
}
//Function qui efface tout
function reset(){
    document.getElementById('output').innerHTML = '0';
    input = "";
}
//Function qui enleve le dernier element de input
function rem1(){
input = input.replace(/.$/,"");
document.getElementById('output').innerHTML = input;
}
//Function qui ouvre le drawer
function openNav() {
    document.getElementById("mySlideUp").style.top = "50%";
    document.body.style.backgroundColor = "white";
}

    function closeNav() {
    document.getElementById("mySlideUp").style.top = "90%";
    document.body.style.backgroundColor = "rgb(53,52,52)";
}

